import { v4 as uuidv4 } from 'uuid';

export const INTERVIEW_EXPERIENCES = [
  {
    id: uuidv4(),
    image: "https://images.unsplash.com/photo-1560264280-88b68371db39?w=500&auto=format",
    company: "Google",
    role: "Senior Frontend Developer",
    author: "John Doe",
    date: "December 15, 2023",
    experience: `The interview process at Google was comprehensive and well-structured. It consisted of:

1. Initial Phone Screen (45 minutes)
- Basic JavaScript concepts
- DOM manipulation
- Event handling

2. Technical Round 1 (1 hour)
- Algorithm problem solving
- Data structures
- Time complexity analysis

3. Technical Round 2 (1 hour)
- System design
- Scalability considerations
- Performance optimization

4. Final Round (1 hour)
- Behavioral questions
- Team fit assessment
- Project discussions

Key Tips:
- Focus on clean code
- Think aloud during problem-solving
- Ask clarifying questions
- Discuss trade-offs in your solutions`
  },
  {
    id: uuidv4(),
    image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=500&auto=format",
    company: "Microsoft",
    role: "Full Stack Developer",
    author: "Jane Smith",
    date: "December 10, 2023",
    experience: `Microsoft's interview process was thorough and focused on both technical skills and problem-solving ability. The process included:

1. Recruiter Call (30 minutes)
- Background discussion
- Role overview
- Initial screening

2. Technical Assessment
- Coding challenge
- Architecture design
- API design principles

3. Virtual Onsite (4 hours)
- System design
- Coding rounds
- Behavioral interview

Key Learnings:
- Practice system design
- Review core CS concepts
- Prepare real-world examples
- Focus on scalability`
  },
  {
    id: uuidv4(),
    image: "https://images.unsplash.com/photo-1616469829581-73993eb86b02?w=500&auto=format",
    company: "Amazon",
    role: "Software Development Engineer",
    author: "Mike Johnson",
    date: "December 5, 2023",
    experience: `Amazon's interview process was challenging but fair. Here's my experience:

1. Online Assessment
- Data structures
- Algorithms
- Coding implementation

2. Technical Phone Screen
- Problem-solving
- Code optimization
- Time complexity analysis

3. Virtual Onsite
- System design
- Object-oriented design
- Leadership principles

Tips for Success:
- Study Amazon's leadership principles
- Practice coding on whiteboard
- Focus on scalable solutions
- Prepare behavioral examples`
  }
];